let counter = 0;

const ToggleField = (label='toggle', defaultValue=false, name=`${counter++}`) => {
    return {
        type: 'boolean',
        name,
        label,
        defaultValue,
    }
};

const TextField = (label='text', defaultValue='', name=`${counter++}`) => {
    return {
        type: 'string',
        name,
        label,
        defaultValue,
    }
};

const lyricsExtensionSettings = {
    currentFontSize: 'x-large',
    nextFontSize: 'larger',
    showRomaLyric: false,
    showTranslatedLyric: false,
};

let _settings;

async function onSetting(safeStore) {
    _settings = safeStore;
    const settings = await safeStore.get();
    if (!settings) {
        safeStore.set(lyricsExtensionSettings);
    } else {
        Object.assign(lyricsExtensionSettings, settings);
    }

    return [
        TextField(
            '当前歌词字体大小',
            lyricsExtensionSettings.currentFontSize,
            'currentFontSize'
        ),
        TextField(
            '下一句歌词字体大小',
            lyricsExtensionSettings.nextFontSize,
            'nextFontSize'
        ),
        ToggleField(
            '显示罗马音',
            lyricsExtensionSettings.showRomaLyric,
            'showRomaLyric'
        ),
        ToggleField(
            '显示中文翻译',
            lyricsExtensionSettings.showTranslatedLyric,
            'showTranslatedLyric'
        )
    ]
}

function onSetSetting(name, value) {
    lyricsExtensionSettings[name] = value;
    _settings.set(lyricsExtensionSettings);
}

function onGetSetting(name) {
    return lyricsExtensionSettings[name]
}

export { lyricsExtensionSettings, onGetSetting, onSetSetting, onSetting };
